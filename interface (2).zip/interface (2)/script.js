var painter = document.querySelectorAll('.player')
painter.forEach(player => {
    player.addEventListener("click", activePainter)
});

function activePainter(event) {
    painter.forEach(player => {
        player.classList.remove('active')
    });
    event.target.classList.add('active');

    setPainterImg(event.target.id);
    setBodyBG(event.target.id);
    setPlayerName(event.target.id)
}

function setPlayerName(id) {
    document.querySelector('h1').innerHTML = `Player ${id}`;
}
function setPainterImg(id) {
    document.querySelector('#selectedPainterImage').src = `images/${id}.png`;
}
function setBodyBG(id) {
    document.querySelector('body').style.background = gradinetBG[id]
}


const gradinetBG = {
    blue: `radial-gradient(circle, rgba(123,152,237,1) 5%, rgba(211,211,211,1) 95%)`,
    green: `radial-gradient(circle, rgba(123, 237, 159, 1) 5%, rgba(211, 211, 211, 1) 95%)`,
    orange: `radial-gradient(circle, rgba(237,190,123,1) 5%, rgba(211,211,211,1) 95%)`,
    purple : `radial-gradient(circle, rgba(147,119,204,1) 5%, rgba(211,211,211,1) 95%)`,
    brown : `radial-gradient(circle, rgba(233,165,150,1) 5%, rgba(211,211,211,1) 95%)`,
    red : `radial-gradient(circle, rgba(255,124,146,1) 5%, rgba(211,211,211,1) 95%)`,
    black : `radial-gradient(circle, rgba(102,97,109,1) 5%, rgba(211,211,211,1) 95%)`,
}


const playerKeys = {
    player1: {
        up: 'w', left: 'a', down: 's', right: 'd'
    },

}